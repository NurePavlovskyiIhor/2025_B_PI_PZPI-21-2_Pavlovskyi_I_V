#pragma once

namespace Components
{
	struct CubeComponent
	{
		bool active = true;
	};
}
