#pragma once

class Scene
{
public:

private:

};