#pragma once
#include <SimpleMath.h>

using namespace DirectX::SimpleMath;